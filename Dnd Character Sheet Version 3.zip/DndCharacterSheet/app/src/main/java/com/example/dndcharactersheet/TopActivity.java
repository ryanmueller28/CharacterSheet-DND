package com.example.dndcharactersheet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TopActivity extends AppCompatActivity {

    private Button buttonTop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_top);

        buttonTop = (Button) findViewById(R.id.buttonTop);
        buttonTop.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
               openMiddleActivity();
            }
        });
    }

    public void openMiddleActivity() {
        Intent intent = new Intent(this, MiddleActivity.class);
        startActivity(intent);
    }
}
