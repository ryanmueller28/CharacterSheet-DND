package com.example.dndcharactersheet;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MiddleActivity extends Activity {

    private Button middleBackButton;
    private Button firstCharacter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_middle);

        middleBackButton = (Button) findViewById(R.id.middleBackButton);
        middleBackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTopActivity();
            }
        });

        firstCharacter = (Button) findViewById(R.id.firstCharacter);
        firstCharacter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMainActivity();
            }
        });

    }

    public void openTopActivity() {
        Intent intent = new Intent(this, TopActivity.class);
        startActivity(intent);
    }

    public void openMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
