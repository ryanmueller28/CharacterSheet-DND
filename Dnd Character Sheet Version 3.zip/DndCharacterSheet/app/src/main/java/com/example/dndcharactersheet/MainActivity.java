package com.example.dndcharactersheet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button mainBackButton;
    private Button mainFrontButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainBackButton = (Button) findViewById(R.id.mainBackButton);
        mainBackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMiddleActivity();
            }
        });

        mainFrontButton = (Button) findViewById(R.id.mainFrontButton);
        mainFrontButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSpellActivity();
            }
        });

    }

    public void openMiddleActivity() {
        Intent intent = new Intent(this, MiddleActivity.class);
        startActivity(intent);
    }

    public void openSpellActivity() {
        Intent intent = new Intent(this, SpellActivity.class);
        startActivity(intent);
    }
}
