package com.example.dndcharactersheet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CharacterDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_character_details);
    }
}
